RTTM AI - Backend (ready for Render.com)

Fayl tuzilmasi:
rttm_backend/
├─ app.py
├─ requirements.txt
└─ utils/
   └─ model_service.py

Deploy (Render.com):
1) GitHub repo yarating va ushbu papkani unga push qiling.
2) Render.com -> New -> Web Service -> GitHub repo tanlang.
3) Environment: Python 3
4) Build command:
   pip install -r requirements.txt
5) Start command:
   uvicorn app:app --host 0.0.0.0 --port $PORT

Keyingi qadamlar:
- Render deploy tugagach, siz URL olasiz, masalan:
  https://rttm-backend.onrender.com
- Ushbu URL ni Flutter ilovadagi lib/services/plant_model_service.dart ichidagi apiUrl bilan almashtiring.

Eslatma:
Men uzr so‘rayman: men o‘zimdan tarmoqga ulanib Render.com'ga deploy qila olmayman. Shu sababli sizga backend fayllarini tayyorlab berdiim — siz yoki men sizga qadam-baqadam ekran rasmlari bilan deploy qilishni ko‘rsataman.
